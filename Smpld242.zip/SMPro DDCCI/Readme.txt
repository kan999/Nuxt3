About ScreenManager Pro for LCD (DDC/CI)


================================================================================
1)  Contents of Folders
================================================================================
- User's Manual
   - User's Manual of ScreenManager Pro for LCD (DDC/CI)
- Software                                 Version      OS
   - ScreenManager Pro for LCD (DDC/CI)    [Ver.2.4.2]  Windows 8.1 (32 bit/64 bit)
                                                        Windows 8 (32 bit/64 bit)
                                                        Windows 7 SP1 (32 bit/64 bit)
- Readmeja.txt file (Japanese)
- Readme.txt file (English)

================================================================================
2)  Opening Menu
================================================================================
Double click "Launcher.exe" to open the menu.


Copyright (C) 2009-2014 EIZO Corporation.  All rights reserved.